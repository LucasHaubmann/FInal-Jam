export enum PlayerState {
  Idle = "Idle",
  Jumping = "Jumping",
  Falling = "Falling",
  Death = "Death",
}
