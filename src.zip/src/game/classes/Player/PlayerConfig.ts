export const PlayerConfig = {
  width: 40,
  height: 40,
  gravity: 0.8,
  jumpForce: -15,
  groundY: 600, 
  speedX: 4
};
