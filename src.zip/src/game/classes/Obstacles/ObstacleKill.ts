import p5 from "p5";
import { ObstacleBlock } from "./ObstacleBlock";
import { isRectColliding } from "./ObstacleCollision"; // importa da onde você colocou

export class ObstacleKill extends ObstacleBlock {
  render(p: p5, camX: number): void {
    p.fill("#e63946"); // vermelho sangue
    p.stroke("#ffb4b4");
    p.strokeWeight(2);
    p.rect(this.x - camX, this.y, this.width, this.height);
    p.noStroke();
  }

  isLethal(): boolean {
    return true;
  }

override isColliding(
  px: number, py: number, pw: number, ph: number
): boolean {
  return isRectColliding(px, py, pw, ph, this.x, this.y, this.width, this.height);
}

}
