export enum ObstacleType {
  Block = "block",
  Ramp = "ramp"
}
