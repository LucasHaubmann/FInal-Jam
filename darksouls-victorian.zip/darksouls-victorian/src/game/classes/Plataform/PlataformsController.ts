import p5 from "p5";
import Platform from "../Plataform/Plataform";
import type { IPlatform } from "../Plataform/IPlataform";

export default class PlatformController {
  private platforms: IPlatform[] = [];

  constructor(p: p5) {
    // Exemplo inicial de plataformas
    this.platforms.push(new Platform(p, 300, 500, 200, 20));
    this.platforms.push(new Platform(p, 600, 400, 150, 20));
  }

  update(p: p5): void {
    for (const platform of this.platforms) {
      platform.display(p);
    }
  }

  getPlatforms(): IPlatform[] {
    return this.platforms;
  }
}